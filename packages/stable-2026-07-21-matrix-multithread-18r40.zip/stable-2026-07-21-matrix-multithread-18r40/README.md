﻿# grok-regkit

xAI / Grok **账号自动注册工具包**。

自动完成注册，产出 **SSO**（网页会话 / 号池），并可导出 **OIDC**（`xai-*.json` → CLIProxyAPI → free **Grok 4.5**）。  
支持 **浏览器注册** 与 **混合协议注册**，自带 Web 控制台、GUI、CLI。

> **SSO ≠ OIDC。** 仅有 SSO 不能当 Build 4.5 凭证。详见 [`docs/sso-cpa/`](./docs/sso-cpa/)。

**仅供研究、测试与个人学习。** 请遵守目标站点服务条款与当地法律。详见 [`NOTICE.md`](./NOTICE.md)。

---


---

## 本分支实际能力（相对上游增强）

> 以本机长期实跑为准。完整还原点见 [`STABLE_VERSION.md`](./STABLE_VERSION.md) / [`CHANGELOG.md`](./CHANGELOG.md)。

| 能力 | 说明 |
|------|------|
| 邮箱来源 | 临时邮（CF/Duck/YYDS）+ **微软 Outlook（Graph）** + **AOL（IMAP+TOTP）** 账号池 |
| 邮箱路由 | 按域名/token 自动选 provider（全局配 AOL 时 Outlook 仍走 Graph） |
| 主路径 | **注册成功 → 立即 SSO → 入池**（g2a / Sub2API / CPA）；`pending_sso` 仅兜底 |
| 二次补 SSO | Web「二次补」/ `POST /api/pending-sso/recover`；登录带 **Turnstile**；**只点一次登录**，失败立即 hybrid 重注册 |
| 代理 | 直连 / 单代理 / **SOCKS5 代理池**（可在 Web 页保存） |
| 注册模式 | `hybrid`（协议优先）· `browser`（全浏览器） |
| 入池 | SSO 会话、Sub2API `sso-to-oauth`、CPA `xai-*.json` OIDC、可选 NSFW |
| 控制台 | `http://127.0.0.1:8092`；应用日志不脱敏 |
| 停止策略 | 「停止注册」只停 grok-regkit 任务；**不**停 Sub2API / g2a / CLIProxy / CPA Gateway |

### 推荐还原点

| 用途 | Tag |
|------|-----|
| 文档+全关联同步（当前） | `stable-2026-07-19-docs-sync-18r28i` |
| pending 禁二次登录业务完美点 | `stable-2026-07-19-pending-one-login-18r28h` |

```bash
git fetch mygithub --tags
git checkout stable-2026-07-19-docs-sync-18r28i
```

本地 Packages：`packages/stable-2026-07-19-*.zip`（历史包全部保留）。

### 关联公开仓库

| 项目 | URL |
|------|-----|
| 本仓 grok-regkit | https://github.com/qq1254870524/grok-regkit |
| 服务编排 | https://github.com/qq1254870524/grok-regkit-services |
| Sub2API fork | https://github.com/qq1254870524/sub2api |
| grok2api | https://github.com/qq1254870524/grok2api |
| Turnstile 独立抽取 | https://github.com/qq1254870524/turnstile-harvester1 |
| MuMu 剪贴板隔离 | https://github.com/qq1254870524/mumu-clipboard-isolation |

### 本机默认端口

| 端口 | 服务 |
|------|------|
| 8092 | grok-regkit Web |
| 8080 | Sub2API |
| 8010 | grok2api |
| 8317 | CLIProxyAPI |
| 8318 | CPA Gateway |


## 功能亮点

| 能力 | 说明 |
|------|------|
| 双注册模式 | `browser` 全浏览器 · `hybrid` 协议 RPC + 短浏览器采 Turnstile/castle |
| 临时邮箱 | **Cloudflare Temp Email** · **DuckMail** · **YYDS Mail**（见下表） |
| SSO 落盘 | `邮箱----密码----sso` → `accounts_*.txt`，可选写入号池 |
| CPA / OIDC | 协议优先 mint → `cpa_auths/xai-*.json` → **grok-4.5** |
| 可选反代 | `deploy/cpa_gateway` + Nginx 模板：多 key 配额暴露 CLIProxy（见下） |
| 多入口 | Web 控制台 · GUI · CLI · backfill 脚本 |

---

## 适配的临时邮箱

配置项：`email_provider`（Web 控制台「邮箱来源」Tab 切换）。  
**browser / hybrid 共用**同一套建号与收验证码逻辑。

| `email_provider` | 服务 | 必填配置 | 说明 |
|------------------|------|----------|------|
| `cloudflare` | [Cloudflare Temp Email](https://github.com/dreamhunter2333/cloudflare_temp_email) 兼容 Worker | `cloudflare_api_base` | 可选 `cloudflare_api_key`、`cloudflare_auth_mode`（`none` / `x-admin-auth` / `bearer` / `x-api-key` / `query-key`）；路径可配 |
| `duckmail` | [DuckMail](https://api.duckmail.sbs) | `duckmail_api_key` | 拉域名 → 建地址 → 轮询邮件 |
| `yyds` | [YYDS Mail](https://vip.215.im/docs) | `yyds_api_key`（或 `yyds_jwt`） | 拉域名 → 建地址 → 轮询验证码 |

### 配置示例

**Cloudflare**

```json
{
  "email_provider": "cloudflare",
  "cloudflare_api_base": "https://your-worker.example.com",
  "cloudflare_auth_mode": "none",
  "cloudflare_api_key": "",
  "defaultDomains": "mail.example.com"
}
```

**DuckMail**

```json
{
  "email_provider": "duckmail",
  "duckmail_api_key": "your-key"
}
```

**YYDS Mail**

```json
{
  "email_provider": "yyds",
  "yyds_api_key": "your-key",
  "yyds_jwt": ""
}
```

更细的路径说明、扩展参考：[`docs/mail-providers.md`](./docs/mail-providers.md)。

---

## 架构

```text
临时邮箱（cloudflare / duckmail / yyds）
              │
              ▼
     注册 accounts.x.ai
     （browser 或 hybrid）
              │
              ▼
          SSO cookie
              │
     ┌────────┴────────┐
     ▼                 ▼
  号池 (SSO)      CPA mint (OIDC)
  Web 模型        xai-*.json → CLIProxyAPI → grok-4.5
```

| 注册模式 | 配置 | 说明 |
|----------|------|------|
| 全浏览器 | `"register_mode": "browser"` | 全程 Chromium，过盾稳 |
| 混合协议 | `"register_mode": "hybrid"` | 浏览器短采 token，业务走协议，通常更快 |

---

## 快速开始

```bash
cd grok-regkit
python -m venv .venv
# Windows
.venv\Scripts\activate
pip install -r requirements.txt
cp config.example.json config.json
# 填写 email_provider + 对应密钥、代理、register_mode
```

### Web（推荐）

```bash
# Linux 无桌面: export DISPLAY=:99  （配合 Xvfb）
uvicorn web.server:app --host 127.0.0.1 --port 8092 --workers 1
```

打开：`http://127.0.0.1:8092`

### GUI / CLI

```bash
python grok_register_ttk.py
python grok_register_ttk.py --cli
```

### 常用配置字段

| 字段 | 说明 |
|------|------|
| `email_provider` | `cloudflare` \| `duckmail` \| `yyds` |
| `register_mode` | `browser` \| `hybrid` |
| `proxy` / `proxy_mode` | 注册代理 |
| `cpa_export_enabled` | 注册后是否 mint OIDC |
| `cpa_prefer_protocol` | 协议 mint 优先 |
| `cpa_auth_dir` | 默认 `./cpa_auths` |

完整示例见 [`config.example.json`](./config.example.json)。

---

## 配套服务仓

本仓库是注册/导入主程序。本机编排（服务管理器、CPA Gateway、CLIProxy 示例配置）见独立公开仓：

- https://github.com/qq1254870524/grok-regkit-services

快速导入 CPA/CLIProxy 的 `xai-*.json` 到 Sub2API：

```bash
# 推荐：客户端 API 直导（兼容官方 Sub2API 镜像，不依赖网页「导入数据」）
python -B scripts/import_cpa_to_sub2api.py --dir "C:/path/to/Grok/cpa"
python -B scripts/import_cpa_to_sub2api.py --file path/to/xai-xxx.json --verify

# 若必须用 Sub2API 网页「导入数据」：先转成 sub2api-data 备份格式
python -B scripts/convert_cpa_to_sub2api_data.py --file path/to/xai-xxx.json --out sub2api_data.json
python -B scripts/convert_cpa_to_sub2api_data.py --dir "C:/path/to/Grok/cpa" --out sub2api_data_bundle.json
# 然后在 http://127.0.0.1:8080 管理后台 → 账号 → 导入数据 → 上传 sub2api_data*.json
```

说明：官方 Sub2API 网页「导入数据」只认 `type=sub2api-data/sub2api-bundle` 备份；原始 `xai-*.json` 不是坏文件，只是入口不匹配。fork 前端已支持直接吃 xai JSON，但需自建镜像才生效。

Web：`http://127.0.0.1:8092` → 号池联动 → CPA 目录 → 导入 CPA 到 Sub2API。

## 可选：反代与 CPA 网关

注册成功并 mint 出 `xai-*.json` 后，可用 **CLIProxyAPI** 提供 OpenAI 兼容接口。  
本仓库 `deploy/` 提供可选参考：

- **cpa-gateway**：多客户端 key + 请求配额，转发到本机 CLIProxy  
- **Nginx 片段**：公网 `/cpa/` → gateway；可选注册 Web 面板反代  

完整步骤与 curl / SDK 示例：[`docs/reverse-proxy.md`](./docs/reverse-proxy.md) · 文件索引：[`deploy/README.md`](./deploy/README.md)。

> 注册机核心**不依赖** `deploy/`。凭证勿混用（SSO ≠ CPA key）。

---

## 产物

| 路径 | 内容 |
|------|------|
| `accounts_*.txt` | browser：`邮箱----密码----sso` |
| `accounts_hybrid_*.txt` | hybrid：同上 |
| `cpa_auths/xai-<email>.json` | OIDC，供 CLIProxyAPI |

存量补 OIDC：

```bash
python scripts/backfill_cpa_xai_from_accounts.py
```

---

## 环境要求

- Python 3.9+（推荐 3.11 / 3.12）
- Chrome / Chromium
- 可访问 `accounts.x.ai`、所选邮箱 API；按需代理
- Linux 服务器建议 Xvfb + 有头 Chromium

---

## 目录

```text
grok-regkit/
  grok_register_ttk.py     # 浏览器注册 + 调度
  hybrid_register.py       # 混合注册
  browser/  protocol/      # hybrid 依赖
  cpa_xai/  cpa_export.py  # OIDC mint
  web/                     # FastAPI 控制台
  deploy/                  # 可选：cpa-gateway + Nginx 模板
  scripts/                 # backfill 等
  docs/
    项目介绍.md
    mail-providers.md      # 邮箱适配说明
    reverse-proxy.md       # 反代 / CPA 网关用法
    sso-cpa/               # SSO / CPA 适配
  config.example.json
```

---

## 文档

| 文档 | 内容 |
|------|------|
| [docs/项目介绍.md](./docs/项目介绍.md) | 中文总览（亮点、模式、速度说明） |
| [docs/mail-providers.md](./docs/mail-providers.md) | 邮箱适配与扩展参考 |
| [docs/sso-cpa/](./docs/sso-cpa/) | SSO ≠ OIDC · 模式矩阵 · 配置 |
| [docs/reverse-proxy.md](./docs/reverse-proxy.md) | 可选反代 · cpa-gateway · curl 示例 |
| [LOCAL_RUN.md](./LOCAL_RUN.md) | 本机运行细节 |
| [OPEN_SOURCE.md](./OPEN_SOURCE.md) | 开源快照维护 |
| [SECURITY.md](./SECURITY.md) | 密钥与安全 |
| [NOTICE.md](./NOTICE.md) | 使用边界 |

---

## 🤝 Acknowledgments and Community

This project is forever grateful for the support and promotion from the [LINUX DO](https://linux.do) community.

本项目感谢 [LINUX DO](https://linux.do) 社区的支持与推广。

---

## License

[MIT](./LICENSE)

## 免责声明

本项目与 xAI / Grok **无官方关系**。自动化可能导致账号或 IP 封禁，使用风险自负。


## 融合：grokRegister-cpa（2026-07-17）

已从 [Git-creat7/grokRegister-cpa](https://github.com/Git-creat7/grokRegister-cpa) 融合以下能力（保留本仓库 hybrid / Web / gateway）：

| 能力 | 配置 | 说明 |
|------|------|------|
| 授权码 mint | `cpa_prefer_authcode` | SSO→PKCE，`referrer=grok-build`，失败回退 device/protocol |
| 远程 CPA 入库 | `cpa_remote_upload` + `cpa_remote_url` + `cpa_management_key` | Management API 上传 `xai-*.json`（密钥须为**明文**） |
| 上游开关别名 | `cpa_auto_add` | 与 `cpa_export_enabled` 同时生效 |
| 独立补转 | `python sso_to_auth_json.py --sso ...` | 已有 SSO 批量转 OIDC / 远程上传 |

本机 CLIProxyAPI 已把 `auth-dir` 指到 `./cpa_auths` 时，**本地热加载已够用**；远程上传主要用于另一台 CPA 实例。

```bash
# 已有 SSO 补转并写本地 cpa_auths
python sso_to_auth_json.py --sso accounts_xxx.txt --cpa-auth-dir ./cpa_auths

# 远程上传（需 CPA management 明文密钥）
python sso_to_auth_json.py --sso accounts_xxx.txt \
  --cpa-remote-url http://127.0.0.1:8317 \
  --cpa-management-key '明文管理密钥'
```

## Sub2API 入池

支持两条路径：

1. **注册成功后的 SSO**：`POST /api/v1/admin/grok/sso-to-oauth`
2. **存量 CPA / CLIProxy OAuth JSON**（`Desktop/Grok/cpa` 或 `cpa_auths/xai-*.json`）：`POST /api/v1/admin/accounts` 直建 `platform=grok type=oauth`

CLI：

```bash
python -B scripts/import_cpa_to_sub2api.py --dir "C:\Users\zhang\Desktop\Grok\cpa"
python -B scripts/import_cpa_to_sub2api.py --file path\to\xai-xxx.json --verify
python -B scripts/import_cpa_to_sub2api.py --dir ./cpa_auths --dry-parse --limit 5
```

Web 控制台「号池联动」页可填写 CPA 目录并一键导入。  
同邮箱 / sub 默认更新已有账号；可用性测试失败默认只告警，不回滚已创建记录。

## 关联仓库

- 本仓: https://github.com/qq1254870524/grok-regkit
- 服务编排: https://github.com/qq1254870524/grok-regkit-services
- Sub2API 修改版: https://github.com/qq1254870524/sub2api
- MuMu 剪贴板隔离: https://github.com/qq1254870524/mumu-clipboard-isolation

